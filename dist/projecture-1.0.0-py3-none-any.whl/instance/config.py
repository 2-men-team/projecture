SECRET_KEY = 'dev'
DB_SCHEMA_FILE = 'schema.sql'
DB_NAME = 'Projecture'
DB_USER = 'root'
DB_PASS = 'root'
DB_HOST = 'localhost'

BRIEF_DESC_LEN = 300


# distributed server configuration system